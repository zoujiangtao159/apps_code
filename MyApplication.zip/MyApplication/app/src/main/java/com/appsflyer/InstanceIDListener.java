package com.appsflyer;

/**
 * Created by shacharaharon on 21/02/2017.
 */

@Deprecated
public class InstanceIDListener extends GcmInstanceIdListener {
}
